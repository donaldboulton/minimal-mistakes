For Orchard Cms 1.7.2 or above, or use the Kama Skin in any CKEditor instance.
Included is the MediaLibrary plugin and a timestamp plugin.
These plugins are added to, CKEditor.Config.cshtml and CKEditor.csproj.

CKEditor 3 not for 4.

Included is my CKEditor Kama Dark skin and Icons

Media Library picker and Timestamp

Working on a dark skin for LuDC.CKEditor 4.3.

Or you can try Moono-dark.