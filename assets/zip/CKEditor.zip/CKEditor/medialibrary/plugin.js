﻿(function () {

	function getUrl(editor) {
		var selection = editor.getSelection(),
			element = selection.getStartElement(),
			insertMode = false;
		if (element)
			element = element.getAscendant('img', true);

		if (!element || element.getName() != 'img' || element.data('cke-realelement')) {
			element = editor.document.createElement('img');
			insertMode = true;
		}
//		else
//			this.insertMode = false;

//		this.element = element;

		//					alert('mediaLibraryDialog');
		var adminIndex = location.href.toLowerCase().indexOf("/admin/");
		if (adminIndex === -1) return;
		var url = location.href.substr(0, adminIndex) + "/Admin/Orchard.MediaLibrary?dialog=true";
		$.colorbox({
			href: url,
			iframe: true,
			reposition: true,
			width: "90%",
			height: "90%",
			onLoad: function () {
				// hide the scrollbars from the main window
				$('html, body').css('overflow', 'hidden');
			},
			onClosed: function () {
				$('html, body').css('overflow', '');

				var selectedData = $.colorbox.selectedData;

				if (selectedData == null || selectedData.length < 1) {
					// Dialog cancelled, do nothing
					return;
				}

				var renderMedia = location.href.substr(0, adminIndex) + "/Admin/Orchard.MediaLibrary/MediaItem/" + selectedData[0].id + "?displayType=Raw";
				$.ajax({
					async: false,
					type: 'GET',
					url: renderMedia,
					success: function (data) {
						var regex = /<img.*?src=['"](.*?)['"]/;
						var src = regex.exec(data)[1];
//						var img = editor.document.createElement('img');
						element.setAttribute('src', src);
						if (insertMode)
							editor.insertElement(element);
					}
				});

			}
		})

	}

	CKEDITOR.plugins.add('medialibrary', {
		icons: 'medialibrary',
		init: function (editor) {
			editor.addCommand('mediaLibraryDialog', {
				exec: getUrl
			}
				);
			editor.ui.addButton('MediaLibrary', {
				label: 'Pick from Orchard Media Library',
				command: 'mediaLibraryDialog',
				toolbar: 'insert'
			});

			if (editor.contextMenu) {
				editor.addMenuGroup('abbrGroup');
				editor.addMenuItem('medialibraryItem', {
					label: 'Pick from Media Library',
					icon: this.path + 'images/medialibrary.png',
					command: 'mediaLibraryDialog',
					group: 'abbrGroup'
				});
                editor.ui.addButton( 'MediaLibrary',
		{
			// Toolbar button tooltip.
			label: 'Pick from Orchard Media Library',
			// Reference to the plugin command name.
			command: 'mediaLibraryDialog',
			// Button's icon file path.
			icon: this.path + 'images/medialibrary.png'
		} );
				editor.contextMenu.addListener(function (element) {
					if (element.getAscendant('img', true)) {
						return { medialibraryItem: CKEDITOR.TRISTATE_OFF };
					}
				});
			}
		}
	});

})();